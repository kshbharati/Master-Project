package com.federation.masters.preuni.api;

import android.content.Context;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.federation.masters.preuni.models.Category;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Map;

public class ApiMain {
    String hostUrl="http://10.0.2.2:8000";
    Context context;
    public ApiMain(Context con)
    {
        context=con;
    }

    JSONArray returnData;

    public JSONArray fetchDataFromUrlUsingGet(String subUrl, JSONArray Data) {
        //RequestQueue queue = Volley.newRequestQueue();
        //JSONObject returnJSON = new JSONObject();
        String requestUrl=hostUrl.concat(subUrl);

        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest
                (Request.Method.GET,
                        requestUrl,
                        null,
                        new Response.Listener<JSONArray>() {

                            @Override
                            public void onResponse(JSONArray response) {
                                returnData=response;
                            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("ERROR",error.toString());
                error.printStackTrace();
            }
        })
        {
            @Override
            public String getBodyContentType()
            {
                return "application/json";
            }
        };



// Access the RequestQueue through your singleton class.
        singleton.getInstance(context).addToRequestQueue(jsonArrayRequest);
        return returnData;
    }
/*
    public JSONArray fetchDataFromUrlUsingPost(Map<String,> parameters) {
        //RequestQueue queue = Volley.newRequestQueue();
        //JSONObject returnJSON = new JSONObject();
        String subUrl;
        if(parameters.containsKey("subUrl"))
        {
            //subUrl=hostUrl.concat(parameters.get("subUrl"));
        }else
        {
            return null;
        }
        String requestUrl=hostUrl.concat(subUrl);

        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest
                (Request.Method.POST,
                        requestUrl,
                        null,
                        new Response.Listener<JSONArray>() {

                            @Override
                            public void onResponse(JSONArray response) {
                                returnData=response;
                            }
                        }, new Response.ErrorListener() {

                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Log.e("ERROR",error.toString());
                                    error.printStackTrace();
                                }
                })
                {
                    @Override
                    public String getBodyContentType()
                    {
                        return "application/json";
                    }
                };



// Access the RequestQueue through your singleton class.
        singleton.getInstance(context).addToRequestQueue(jsonArrayRequest);
        return returnData;
    }
*/
}
